package com.accenture.lkm.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.accenture.lkm.bean.DateBean;
import com.accenture.lkm.bean.PurchaseBean;


public interface ReportService {
	public List<PurchaseBean> getRecordsByDate(DateBean dateBean);
}
