package com.accenture.lkm.dao;

import com.accenture.lkm.bean.LoginBean;
import com.accenture.lkm.entity.LoginEntity;

public interface LoginDao {
//	public boolean validateLogin(LoginBean loginBean);
	public boolean validateLogin(LoginBean loginBean);
}
