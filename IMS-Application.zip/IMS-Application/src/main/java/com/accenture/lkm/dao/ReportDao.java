package com.accenture.lkm.dao;

import java.util.List;

import com.accenture.lkm.bean.DateBean;
import com.accenture.lkm.bean.PurchaseBean;


public interface ReportDao {
	public List<PurchaseBean> getRecordsByDate(DateBean dateBean);
}
