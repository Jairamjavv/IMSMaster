package com.accenture.lkm.dao;

import com.accenture.lkm.bean.PurchaseBean;

public interface PurchaseDao {
public PurchaseBean addPurchase(PurchaseBean purchaseBean);
}
