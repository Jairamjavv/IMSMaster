package com.accenture.lkm.dao;

import com.accenture.lkm.bean.LoginBean;
import com.accenture.lkm.entity.LoginEntity;
import com.accenture.lkm.entity.MaterialCategoryEntity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional(value = "txManager")
public class LoginDaoImpl implements LoginDao {

/*	@PersistenceContext
	private EntityManager entityManager;*/
	

	@Autowired
	private EntityManagerFactory entityManagerFactory;
	
	public boolean validateLogin(LoginBean loginBean) {
		String username = loginBean.getUserName();
		System.out.println(username);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		LoginEntity loginDetailEntity = null;
		try {
			loginDetailEntity = entityManager.find(LoginEntity.class, username);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			entityManager.close();
		}
		return true;
	}

//	public boolean validateLogin(LoginBean loginBean) {
//		System.out.println("Hereeeee dao");
//		String givenName = loginBean.getUserName();
//		String givenPassword = loginBean.getPassword();
//		System.out.println(givenName);
////		EntityManager entityManager = entityManagerFactory.createEntityManager();
////		LoginEntity entity = entityManager.find(LoginEntity.class, givenName);
////		List<MaterialCategoryEntity> entity = entityManager.createQuery("Select k from material_category").getResultList();
//		try {
//			System.out.println(entityManager.createNativeQuery("Select * from material_category").getFirstResult());
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
////		LoginEntity entity = (LoginEntity) entityManager.createQuery("Select k from logindetail where k.username = :value1").setParameter("value1", givenName).getSingleResult();
////		System.out.println(entity);
////		LoginBean beanConverted = convertEntityToBean(entity);
////		System.out.println("qweewwwqeqwewqfdsfvsdgfiusdfgiusdfgiuiu"+givenName);
////		if (givenPassword.equals(beanConverted.getPassword())) {
////			return true;
////		} else {
////			return false;
////		}
///*		Connection con;
//		try{   
//			con=DriverManager.getConnection(  
//			"jdbc:mysql://localhost:3306/materialdb","root","root");  
//			//here sonoo is database name, root is username and password  
//			Statement stmt=con.createStatement();  
//			ResultSet rs=stmt.executeQuery("select * from material_category");  
//			while(rs.next())  
//			System.out.println(rs);  
//			con.close();  
//			}catch(Exception e){ System.out.println(e);}  */
//		return true;
//	}
	
	
	// Utility Methods.......
	public static LoginBean convertEntityToBean(LoginEntity entity) {
		LoginBean customerBean = new LoginBean();
		BeanUtils.copyProperties(entity, customerBean);
		return customerBean;
	}
	public static LoginEntity convertBeanToEntity(LoginBean bean) {
		LoginEntity entity = new LoginEntity();
		BeanUtils.copyProperties(bean, entity);
		return entity;
	}

}
