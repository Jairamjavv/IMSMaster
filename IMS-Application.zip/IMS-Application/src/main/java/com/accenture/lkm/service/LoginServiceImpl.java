package com.accenture.lkm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.lkm.bean.LoginBean;
import com.accenture.lkm.dao.LoginDao;
import com.accenture.lkm.dao.LoginDaoImpl;

@Service
public class LoginServiceImpl implements LoginService {
//	@Autowired
//	LoginDaoImpl loginDao;

	public boolean validateLogin(LoginBean loginBean) {
		LoginDaoImpl ld = new LoginDaoImpl();
		System.out.println(loginBean.getPassword());
		boolean b = ld.validateLogin(loginBean);
		return b;
	}

}
