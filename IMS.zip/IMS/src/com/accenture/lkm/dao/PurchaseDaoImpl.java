package com.accenture.lkm.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.accenture.lkm.bean.LoginBean;
import com.accenture.lkm.bean.PurchaseBean;
import com.accenture.lkm.entity.LoginEntity;
import com.accenture.lkm.entity.PurchaseEntity;

@Repository
public class PurchaseDaoImpl implements PurchaseDao {

	@Autowired
	EntityManagerFactory entityManagerFactory;
	
	public PurchaseBean addPurchase(PurchaseBean purchaseBean) {
		purchaseBean.setStatus("Pending");
		String transId = this.generateTransId(purchaseBean);
		purchaseBean.setTransId(transId);
		PurchaseEntity purchaseEntity=convertBeanToEntity(purchaseBean);
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(purchaseEntity);
		entityManager.getTransaction().commit();
		entityManager.getTransaction().begin();
		purchaseEntity.setTransId(purchaseEntity.getTransId().concat(Integer.toString(purchaseEntity.getPurchaseId())));
		entityManager.getTransaction().commit();
		PurchaseBean purchaseBean2=convertEntityToBean(purchaseEntity);
		return purchaseBean2;
	}

	private String generateTransId(PurchaseBean bean) {
		String one = bean.getVendorName();
		one = one.substring(0, 3);
		Date two = bean.getPurchaseDate();
		DateFormat dateFormat = new SimpleDateFormat("ddmmyyyy");
		String strDate = dateFormat.format(two);
		String three = bean.getMaterialCategory();
		three = three.substring(0, 3);
		String transid = one + strDate + three;
		return transid;
	}
	
	public static PurchaseBean convertEntityToBean(PurchaseEntity entity) {
		PurchaseBean purchaseBean =new PurchaseBean();
		BeanUtils.copyProperties(entity, purchaseBean);
		return purchaseBean;
	}
	public static PurchaseEntity convertBeanToEntity(PurchaseBean bean) {
		PurchaseEntity purchaseEntity=new PurchaseEntity();
		BeanUtils.copyProperties(bean, purchaseEntity);
		return purchaseEntity;
	}

}
