package com.accenture.lkm.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.lkm.bean.DateBean;
import com.accenture.lkm.bean.LoginBean;
import com.accenture.lkm.bean.PurchaseBean;
import com.accenture.lkm.service.LoginService;
import com.accenture.lkm.service.LoginServiceImpl;
import com.accenture.lkm.service.PurchaseServiceImpl;

@Controller
public class LoginController {
	/*
	 * @Autowired private LoginService loginService;
	 */
	private PurchaseServiceImpl psi;
//	@Autowired
//	private LoginService loginService;
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView loginPage() throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("loginPage");
		mav.addObject("loginObject", new LoginBean());
		return mav;
	}

	@RequestMapping(value = "/validateLogin", method = RequestMethod.POST)
	public ModelAndView validateLogin(@ModelAttribute("loginObject") LoginBean lb) {
		System.out.println(lb.getUserName());
		System.out.println("Here");
		
		ModelAndView mav = new ModelAndView();
		LoginServiceImpl loginService = new LoginServiceImpl();
		boolean b = loginService.validateLogin(lb);
		mav.setViewName("success");
		System.out.println(b);
//		if(b == true){
//			mav.setViewName("purchaseTemplate");
//		}
//		mav.setViewName("purchaseTemplate");
	/*	if(lb.getUserName() == "admin" && lb.getPassword() == "admin")	{
			mav.setViewName("purchaseTemplate");
		}*/
		return mav;
	}
	
//	@RequestMapping(value = "/purchasePage", method = RequestMethod.GET)
//	public ModelAndView purchasePage() throws Exception {
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("purchasePage");
//		mav.addObject("purchaseBean", new PurchaseBean());
//		return mav;
//	}
//	
//	@RequestMapping(value = "/purchaseEntry", method = RequestMethod.POST)
//	public ModelAndView addPurchaseEntry(@ModelAttribute("purchaseBean") PurchaseBean pBean) throws Exception{
//		ModelAndView mav = new ModelAndView();
//
//		mav.setViewName("success");
//		PurchaseBean pb = psi.addPurchase(pBean);
//		mav.addObject("resultPurchaseBean",
//				pb.getVendorName() + pb.getMaterialCategory() + pb.getMaterialType() + pb.getBrandName() + pb.getUnit()
//						+ pb.getQuantity() + pb.getPurchaseAmount() + pb.getPurchaseDate() + pb.getPurchaseId()
//						+ pb.getTransId());
//
//		return mav;
//	}
//	
//	@RequestMapping(value = "/purchaseReport", method = RequestMethod.GET)
//	public ModelAndView dateWisePurchaseReport() {
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("dateWiseReport");
//		mav.addObject("dateBean", new DateBean());
//
//		return mav;
//	}
	
	

//	@ModelAttribute("vendorList")
//	public List<VendorBean> generateVendorList() throws Exception {
//		List<VendorBean> vendorList = vendorServiceConsumer.getVendorBeanList();
//		return vendorList;
//	}

//	public ModelAndView getRecordsByDate(@ModelAttribute("dateObj")DateBean dateBean)throws Exception{
//		try {
//			Date startDate=dateBean.getStartDate();
//			Date endDate=dateBean.getEndDate();
//			String name = dateBean.getVendorName();
//			String start = startDate.toString();
//			String end = endDate.toString();
//			System.out.println(name);
//			System.out.println(start);
//			System.out.println(end);
//		ModelAndView modelAndView=new ModelAndView();
//		List<PurchaseBean> allList=reportService.getRecordsByDate(dateBean);
//		modelAndView.setViewName("reportGenerator");
//		modelAndView.addObject("allList",allList);		
//		return modelAndView;
//		} catch (Exception e) {
//			// TODO: handle exception
//			throw e;
//		}
}
