package com.accenture.lkm.web.controller;

//import java.sql.Date;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.lkm.bean.DateBean;
import com.accenture.lkm.bean.VendorBean;
import com.accenture.lkm.service.LoginService;
import com.accenture.lkm.service.ReportService;
import com.accenture.lkm.service.ReportServiceImpl;

@Controller
public class PurchaseReportController {
	
//	@Autowired
//	ReportServiceImpl reportService;
//	
//	@RequestMapping(value = "/purchaseReport", method = RequestMethod.GET)
//	public ModelAndView dateWisePurchaseReport() {
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("dateWiseReport");
//		mav.addObject("dateBean", new DateBean());
//
//		return mav;
//	}

//	@ModelAttribute("vendorList")
//	public List<VendorBean> generateVendorList() throws Exception {
//		List<VendorBean> vendorList = vendorServiceConsumer.getVendorBeanList();
//		return vendorList;
//	}

//	public ModelAndView getRecordsByDate(@ModelAttribute("dateObj")DateBean dateBean)throws Exception{
//		try {
//			Date startDate=dateBean.getStartDate();
//			Date endDate=dateBean.getEndDate();
//			String name = dateBean.getVendorName();
//			String start = startDate.toString();
//			String end = endDate.toString();
//			System.out.println(name);
//			System.out.println(start);
//			System.out.println(end);
//		ModelAndView modelAndView=new ModelAndView();
//		List<PurchaseBean> allList=reportService.getRecordsByDate(dateBean);
//		modelAndView.setViewName("reportGenerator");
//		modelAndView.addObject("allList",allList);		
//		return modelAndView;
//		} catch (Exception e) {
//			// TODO: handle exception
//			throw e;
//		}
}

