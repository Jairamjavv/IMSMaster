package com.accenture.lkm.service;

import org.springframework.stereotype.Service;

import com.accenture.lkm.bean.PurchaseBean;

public interface PurchaseService {
	public PurchaseBean addPurchase(PurchaseBean purchaseBean);
}
