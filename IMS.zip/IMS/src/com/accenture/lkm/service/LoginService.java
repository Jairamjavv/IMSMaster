package com.accenture.lkm.service;

import com.accenture.lkm.bean.LoginBean;
import com.accenture.lkm.bean.PurchaseBean;

public interface LoginService {
	public boolean validateLogin(LoginBean loginBean);
}
